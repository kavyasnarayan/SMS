package com.cg.sms.bean;
import java.time.LocalDate;
public class StudentBean {



		private String rollNo;
		private String name;
		private float fee;
		private LocalDate dateOfJoining;
		private String phoneNumber; 
		
		public String getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		public String getRollNo() {
			return rollNo;
		}
		public void setRollNo(String rollNo) {
			this.rollNo = rollNo;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public float getFee() {
			return fee;
		}
		public void setFee(float fee) {
			this.fee = fee;
		}
		public LocalDate getDateOfJoining() {
			return dateOfJoining;
		}
		public void setDateOfJoining(LocalDate dateOfJoining) {
			this.dateOfJoining = dateOfJoining;
		}
/*		@Override
		public String toString() {
			return "StudentData [rollNo=" + rollNo + ", name=" + name
					+ ", fee=" + fee + ", dateOfJoining=" + dateOfJoining
					+ ", phoneNumber=" + phoneNumber + "]";
		}
*/		
}

