package com.cg.sms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;



public class DynamicFetchDB {

	public static void main(String[] args) {
		
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String user="system";
		String password="root";
		String sql="SELECT id,name FROM student WHERE course=?";
		
		Connection connection = null;
		PreparedStatement preparedStatement= null; 
		ResultSet resultSet = null;
		
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			connection = DriverManager.getConnection(url, user, password);
			System.out.println(connection.getAutoCommit());
			preparedStatement = connection.prepareStatement(sql);
			System.out.println("Enter Course");;
			preparedStatement.setString(1, new Scanner(System.in).next());
			
			resultSet=  preparedStatement.executeQuery();
			
			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1)+" "+resultSet.getString(2));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			
			try {
				if(resultSet !=null && preparedStatement!=null && connection !=null)
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
	}

}
