package com.cg.sms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.net.aso.s;

public class FetchDB {

	public static void main(String[] args) {
		
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String user="system";
		String password="root";
		Connection connection= null;
//		PreparedStatement preparedStatement=null;
		Statement statement = null;
		ResultSet resultSet= null;
		String sql="SELECT name,id,course FROM student";
		
		
		
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			connection = DriverManager.getConnection(url, user, password);
//			preparedStatement = connection.prepareStatement(sql);
			statement = connection.createStatement();
			resultSet =  statement.executeQuery(sql);
			while (resultSet.next()) {
				System.out.println(resultSet.getString(1)+" "+resultSet.getString(3)+" "+resultSet.getInt(2));
			}
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(resultSet!=null && statement!=null && connection !=null)
				resultSet.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
	}

}
