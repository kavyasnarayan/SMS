package com.cg.sms.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.Scanner;






public class StudentDaoImpl {
	public int insertTable(){
//		int result=-1;
		
		InputStream inputStream=null;
		Properties properties= new Properties();
		try {
			inputStream =new FileInputStream("resources/dbStudent.properties");
			properties.load(inputStream);
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String url=properties.getProperty("url");
		String user=properties.getProperty("user");
		String password=properties.getProperty("password");
//		String drive = properties.getProperty("drive");
		Connection connection=null;
//		String createsql="CREATE TABLE student(id number,name VARCHAR2(25),course VARCHAR2(10))";
		
		
		
		
		
		String sql="INSERT INTO student (id,name,course,doj) VALUES (?,?,?,?)";
		Scanner scanner= new Scanner(System.in);
		PreparedStatement preparedStatement = null;
		
		
		do{
		
		System.out.println("Enter Roll Number:");
		int id = scanner.nextInt();
		System.out.println("Enter Name:");
		String name= scanner.next();
		System.out.println("Enter Course Name:");
		String course = scanner.next();
		System.out.println("Enter DOJ (dd/MM/yyyy):");
		String doj = scanner.next();
		 
				DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate date = LocalDate.parse(doj, dateTimeFormatter);
		
		try {
			
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver()); 
			//			Class.forName(drive);
			connection = DriverManager.getConnection(url, user, password);
			preparedStatement = connection.prepareStatement(sql);
			connection.setAutoCommit(false);
			
			preparedStatement.setInt(1, id);
			preparedStatement.setString(2, name);
			preparedStatement.setString(3, course);
			preparedStatement.setDate(4, java.sql.Date.valueOf(date));
			
			int result = preparedStatement.executeUpdate();
			
			if(result==1){
				connection.commit();
				System.out.println("Values inserted Succesfully.");
			}
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		finally{
			
			try {
				if(preparedStatement!=null && connection!=null&& inputStream!=null){
				preparedStatement.close();
				connection.close();
				inputStream.close();
				
				}		
				
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Do you want to continue.? (Y)");
		}while(scanner.next().charAt(0)=='Y');
		
		return 0;
		
	}
	
}
