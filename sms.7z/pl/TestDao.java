package com.cg.sms.pl;

import com.cg.sms.dao.StudentDaoImpl;

public class TestDao {
	public static void main(String[] args) {
		StudentDaoImpl daoImpl= new StudentDaoImpl();
		int result= daoImpl.insertTable();
//		if(result)
	}
}
