package com.cg.sms.pl;




import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.exception.StudentException;
import com.cg.sms.service.IStudentService;
import com.cg.sms.service.StudentServiceImpl;
import com.sun.javafx.scene.control.skin.VirtualFlow.ArrayLinkedList;

public class StudentMain {
	
	
	static IStudentService valid = new StudentServiceImpl();
	public static void main(String args[]) throws StudentException {
	
		PropertyConfigurator.configure("resources//log4j.properties");
		String choice = "1";
	
	StudentBean studentBean = new StudentBean();
	Scanner scanner = new Scanner(System.in);
	IStudentService iStudentService  = new StudentServiceImpl();
	studentBean=null;
	do{

			System.out.println();
			System.out.println();
			System.out.println("   STUDENT MANAGEMENT SYSTEM APPLICATION");
			System.out.println("_____________________________________________\n");
			System.out.println("Select Menu:\n1.Add Student\n2.Modify Student\n3.Show Student\n4.Exit\n");
			System.out.println("_____________________________________________");
			System.out.println("\nSelect an option:");
			
					choice=scanner.next();
					
					switch (choice)
					{
						case "1":
							System.out.println("Add Student");
							studentBean=populateStudentBean();
							iStudentService.addStudent(studentBean);
							System.out.println("Student added");
							
							break;
							
						case "2":
							System.out.println("Modify Student");
							modifyStudent();
							break;
							
						case "3":
							System.out.println("Show Student");
							List<StudentBean> studentBeans = iStudentService.retriveAll();
							boolean flag= false;
							for (StudentBean studentBean1 : studentBeans) {
								showStudent(studentBean1);
								flag=true;
							}
							if(flag==false)
								System.out.println("No Data");
							
							break;
						case "4":
							System.out.println("Exit");
							System.out.println("_____________________________________________\n");
							System.out.println("Application Ended. Thank You !!");
							System.out.println("_____________________________________________\n");
							System.exit(0);
							break;
		
						default:
							System.out.println("Enter valid Choice [1-4] .!!");

					}
    System.out.println("Do you Want to Continue (Y) :");
    if(scanner.next().charAt(0)!='Y'){
    	System.out.println("_____________________________________________\n");
    	System.out.println("Application Ended. Thank You !!");
    	System.out.println("_____________________________________________\n");
    	break;
    	}
    
	}while(!choice.equals("4"));

	}

	
	
	
	private static void modifyStudent() {
		System.out.println("Modify.");
	}



	private static void showStudent(StudentBean studentBean) {
		
		if(studentBean!=null){
		System.out.println("Roll Number : ");
		System.out.println(studentBean.getRollNo());
		System.out.println("Name of Student : ");
		System.out.println(studentBean.getName());
		System.out.println("Total Fee : ");
		System.out.println(studentBean.getFee());
		System.out.println("Phone Number of Student : ");
		System.out.println(studentBean.getPhoneNumber());
		System.out.println("\n");
		}
		
	}


private static StudentBean populateStudentBean() throws StudentException{

	
	 String rollNo=null;
	 String name=null;
	float fee=0.0f;
//	String dateOfJoining=null;
	String phoneNumber= null ;
	
	Scanner scanner = new Scanner(System.in);
	
	System.out.println("Enter Roll Number :");
 	rollNo = scanner.next();
 	
	System.out.println("Enter Name :");
	name = scanner.next();
	
	System.out.println("Enter Fee :");
	fee = scanner.nextFloat();
	System.out.println("Enter Phone Number :");
	phoneNumber=scanner.next();
	
	//set values in studentBean
	StudentBean studentBean = new StudentBean();
	studentBean.setRollNo(rollNo);
	
	studentBean.setName(name);
	
	studentBean.setFee(fee);
	
	studentBean.setPhoneNumber(phoneNumber);
	
	
StudentServiceImpl studentServiceImpl= new StudentServiceImpl();
	
//System.out.println(studentServiceImpl.validateStudent(studentBean));
	try{	
	if(studentServiceImpl.validateStudent(studentBean)!=false){
			
				return studentBean;
		}
	}catch(StudentException exception){
		System.err.println(exception.getMessage());
	}
		return null;
	}
}


