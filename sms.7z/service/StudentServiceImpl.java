package com.cg.sms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.exception.StudentException;
import com.sun.javafx.scene.control.skin.VirtualFlow.ArrayLinkedList;

public class StudentServiceImpl implements IStudentService {
	static List<StudentBean> studentArray = new ArrayList<>();
	/*******************************************************************************************************
	 - Function Name	:	addStudent
	 - Input Parameters	:	StudentBean studentBean
	 - Return Type		:	void
	 - Throws			:  	StudentException
	 - Author			:	Capgemini
	 - Creation Date	:	20/03/2018
	 - Description		:	adding StudentBean to database calls ArrayLinkedlist
	 ********************************************************************************************************/
	
	@Override
	public void addStudent(StudentBean studentBean) throws StudentException {
		// TODO Auto-generated method stub
		studentArray.add(studentBean);
	}
	
	
	/*******************************************************************************************************
	 - Function Name	:	addStudent
	 - Input Parameters	:	StudentBean studentBean
	 - Return Type		:	void
	 - Throws			:  	StudentException
	 - Author			:	Capgemini
	 - Creation Date	:	20/03/2018
	 - Description		:	adding StudentBean to database calls ArrayLinkedlist
	 ********************************************************************************************************/
	
	@Override
	public List<StudentBean> retriveAll() throws StudentException {
		// TODO Auto-generated method stub
		
		return studentArray;
	}
	
	
	
	/*******************************************************************************************************
	 - Function Name	: validateStudent(StudentBean studentBean)
	 - Input Parameters	: StudentBean studentBean
	 - Return Type		: boolean
	 - Throws		    : StudentException
	 - Author	      	: Capgemini	 
	 - Creation Date	: 20/03/2018
	 - Description		: validates the StudentBean object
	 ********************************************************************************************************/

	@SuppressWarnings("finally")
	public boolean validateStudent(StudentBean studentBean)throws StudentException {
	
		 String rollNo=null;
		 String name=null;
		float fee=0.0f;
		String dateOfJoining=null;
		String phoneNumber=null; 
		boolean flag=false;
		String errorMessage="";
		

		//Validating Student Name
		
		name=studentBean.getName();
		Pattern namePattern = Pattern.compile("^[A-Z][A-Za-z\\s]{2,9}$");
		Matcher nameMatcher = namePattern.matcher(name);
	
		if(!nameMatcher.matches()){
			errorMessage+="\nStudent Name Should Be In Alphabets and minimum 3 characters long.";
		}
		
		//Validating Phone number
		phoneNumber=studentBean.getPhoneNumber();
		Pattern phoneNumberPattern = Pattern.compile("^\\d{10}$");
		Matcher phoneNumberMatcher = phoneNumberPattern.matcher(phoneNumber);
		
		
		if(!phoneNumberMatcher.matches()){
			errorMessage+="Phone number Must be 10 digits.";	
		}
		
		//validating Roll number
		rollNo=studentBean.getRollNo();
		Pattern rollNoPattern = Pattern.compile("^\\d{2}$");
		Matcher rollNumberMatcher = rollNoPattern.matcher(rollNo);
		
		
		if(!rollNumberMatcher.matches()){
			errorMessage+="\nRoll number Must be 2 digits.";
		}
		if(!errorMessage.isEmpty())
		{
			throw new StudentException(errorMessage);
		}
		flag=true;
		return flag;

	}




	
}


	
