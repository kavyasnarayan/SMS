package com.cg.dao;

import com.cg.bean.StudentBean;
import com.cg.exception.StudException;

public interface IStudentDao {
	public boolean insertStudentDetails(StudentBean bean) throws StudException;
}
