package com.cg.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.Scanner;

import com.cg.bean.StudentBean;


public class StudentDaoImpl implements IStudentDao{

	public boolean insertStudentDetails(StudentBean bean){
		boolean result=false;
		Properties properties = new Properties();
		InputStream inputStream = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			inputStream = new FileInputStream("resources/dbprob.properties");
			properties.load(inputStream);
			String user = properties.getProperty("User");
			String password = properties.getProperty("password");
			String url = properties.getProperty("url");
			String sql = "insert into student(Id,Name,Course,doj) values(?,?,?,?)";

			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			connection = DriverManager.getConnection(url, user, password);
			connection.setAutoCommit(false);
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, bean.getId());
			preparedStatement.setString(2, bean.getName());
			preparedStatement.setString(3, bean.getCourse());
			preparedStatement.setDate(4, java.sql.Date.valueOf(bean.getDoj()));
			int result1 = preparedStatement.executeUpdate();
			if (result1 == 1) {
				connection.commit();
				result=true;
			}

		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} finally {
			if (preparedStatement != null && connection != null) {
				try {
					preparedStatement.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
		return result;

	}

}
