package com.cg.service;

import com.cg.bean.StudentBean;
import com.cg.dao.IStudentDao;
import com.cg.dao.StudentDaoImpl;
import com.cg.exception.StudException;

public class StudentServiceImpl  implements IStudentService{
	
	

	@Override
	public boolean addDetails(StudentBean bean) throws StudException {

		IStudentDao dao=new StudentDaoImpl();
		return dao.insertStudentDetails(bean);
	}
}