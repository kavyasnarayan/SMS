package com.cg.service;

import com.cg.bean.StudentBean;
import com.cg.exception.StudException;

public interface IStudentService {

	boolean addDetails(StudentBean bean) throws StudException;
}
