package com.cg.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.bean.StudentBean;
import com.cg.exception.StudException;
import com.cg.service.IStudentService;
import com.cg.service.StudentServiceImpl;

public class StudentPl {

	public static void main(String[] args) {

		StudentBean studentBean = new StudentBean();
		Scanner in = new Scanner(System.in);

		System.out.println("\nOption1. Add new student");
		System.out.println("\nEnter Student Roll Number");
		int rollNum = in.nextInt();
		studentBean.setId(rollNum);

		System.out.println("\nEnter Student Name");
		String Name = in.next();
		studentBean.setName(Name);

		System.out.println("\nEnter Student Date of Joining in the format of DD-MON-YYYY");
		String dateStr = in.next();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse(dateStr, formatter);
		studentBean.setDoj(date);
		IStudentService service=new StudentServiceImpl();
		try {
			if(service.addDetails(studentBean)){
				System.out.println(" inserted successfully");
			}
		} catch (StudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		in.close();
	}

}