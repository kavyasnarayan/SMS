package com.cg.exception;

public class StudException extends Exception {

	public StudException(String message){
		super(message);
		// TODO Auto-generated constructor stub
	}

}
