package com.cg.sms.service;

import com.cg.sms.exception.StudentException;

public interface Istudent{

	void addDetails() throws StudentException;
	void modifyDetails() throws StudentException;
	void displayDetails() throws StudentException;
}
 