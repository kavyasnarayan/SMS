package com.cg.sms.bean;

public class StudentBean {

	public StudentBean() {
		
		
	}
	private String rollNo;
	private String sName;
	private String phoneNumber;
	private String dateOfJoining;
	private double fees;
	
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	@Override
	public String toString() {
		return "StudentBean [rollNo=" + rollNo + ", sName=" + sName
				+ ", phoneNumber=" + phoneNumber + ", dateOfJoining="
				+ dateOfJoining + ", fees=" + fees + "]";
	}
	
	
	
	
	

}
